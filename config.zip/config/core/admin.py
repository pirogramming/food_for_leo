from django.contrib import admin

from .models import *


admin.site.register(Brand)
admin.site.register(Mall)
admin.site.register(Product)